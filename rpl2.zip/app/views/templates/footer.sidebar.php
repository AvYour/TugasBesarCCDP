    <!-- main-panel ends -->
    </div>
    <!-- partial ends -->
    </div>
    <!-- container-scroller ends -->
    </div>
    </body>

    </html>
    <script src="<?= BASEURL ?>/js/script.js" type="text/javascript"></script>
    <!-- plugins:js -->
    <script src="<?= BASEURL ?>/vendors/base/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <script src="<?= BASEURL ?>/vendors/chart.js/Chart.min.js"></script>
    <script src="<?= BASEURL ?>/vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="<?= BASEURL ?>/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="<?= BASEURL ?>/js/off-canvas.js"></script>
    <script src="<?= BASEURL ?>/js/hoverable-collapse.js"></script>
    <script src="<?= BASEURL ?>/js/template.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?= BASEURL ?>/js/dashboard.js"></script>
    <script src="<?= BASEURL ?>/js/data-table.js"></script>
    <script src="<?= BASEURL ?>/js/jquery.dataTables.js"></script>
    <script src="<?= BASEURL ?>/js/dataTables.bootstrap4.js"></script>
    <!-- End custom js for this page-->
    <script src="<?= BASEURL ?>/js/jquery.cookie.js" type="text/javascript"></script>