<?php
if (!session_id()) session_start(); 

include_once '../app/init.php';

$app = new App;